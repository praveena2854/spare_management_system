<?php
$qty='prod_qty';
  if($qty <= 10){
echo "<script type='text/javascript'>alert('Low stock restock it
immedietly');</script>";
}
?> 